"use client";

import { useEffect, useState } from "react";

import { listarOportunidades } from "../services/oportunidades.service";

import { Oportunidade } from "../types/oportunidade";

export function useOportunidades() {

  const [loading, setLoading] = useState(true);

  const [oportunidades, setOportunidades] =
    useState<Oportunidade[]>([]);

  async function carregar() {

    setLoading(true);

    try {

      const data =
        await listarOportunidades();

      setOportunidades(data);

    } finally {

      setLoading(false);

    }

  }

  useEffect(() => {

    carregar();

  }, []);

  return {

    oportunidades,

    loading,

    atualizar: carregar,

  };

}