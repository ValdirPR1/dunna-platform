export interface Oportunidade {

  id: string;

  titulo: string;

  etapa:
    | "Novo Lead"
    | "Qualificação"
    | "Visita"
    | "Proposta"
    | "Reserva"
    | "Contrato"
    | "Pós-venda";

  prioridade:
    | "Baixa"
    | "Normal"
    | "Alta";

  probabilidade: number;

  valor_previsto: number;

  previsao_fechamento: string;

  pessoa_id: string;

  corretor_id: string;

  observacoes: string;

  created_at: string;

}