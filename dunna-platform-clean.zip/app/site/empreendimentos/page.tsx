import Link from "next/link";

const empreendimentos = [
  {
    id: "makani",
    nome: "Makani Residence",
    cidade: "Praia dos Carneiros",
  },
  {
    id: "palm-beach",
    nome: "Palm Beach",
    cidade: "Porto de Galinhas",
  },
  {
    id: "beach-class",
    nome: "Beach Class Wave",
    cidade: "Muro Alto",
  },
];

export default function EmpreendimentosPage() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-16">
      <h1 className="text-5xl font-bold">
        Empreendimentos
      </h1>

      <div className="mt-12 grid gap-8 lg:grid-cols-3">

        {empreendimentos.map((item) => (

          <Link
            key={item.id}
            href={`/site/empreendimento/${item.id}`}
            className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm transition hover:shadow-xl"
          >
            <div className="mb-6 h-56 rounded-2xl bg-slate-200" />

            <h2 className="text-2xl font-bold">
              {item.nome}
            </h2>

            <p className="mt-3 text-slate-500">
              {item.cidade}
            </p>

          </Link>

        ))}

      </div>
    </div>
  );
}