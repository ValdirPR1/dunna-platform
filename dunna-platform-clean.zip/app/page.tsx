import DashboardHero from "@/components/dashboard/DashboardHero";
import StatsGrid from "@/components/dashboard/StatsGrid";

export default function DashboardPage() {
  return (
    <div>

      <DashboardHero />

      <StatsGrid />

    </div>
  );
}