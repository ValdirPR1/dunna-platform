import Link from "next/link";

interface Props {
  id: string;
  titulo: string;
  cidade: string;
  preco: string;
  imagem?: string;
}

export default function PropertyCard({
  id,
 titulo,
  cidade,
  preco,
  imagem,
}: Props) {
  return (
    <Link
      href={`/site/imovel/${id}`}
      className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl"
    >
      <img
        src={imagem || "https://placehold.co/800x600"}
        alt={titulo}
        className="h-72 w-full object-cover"
      />

      <div className="p-6">
        <p className="text-sm font-semibold uppercase tracking-wide text-[#C8A96A]">
          {cidade}
        </p>

        <h3 className="mt-2 text-2xl font-bold">
          {titulo}
        </h3>

        <p className="mt-6 text-2xl font-bold">
          {preco}
        </p>
      </div>
    </Link>
  );
}