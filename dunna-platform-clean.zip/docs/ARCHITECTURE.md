# DUNNA PLATFORM

## Arquitetura Oficial

---

# Stack

- Next.js 15
- React
- TypeScript
- Tailwind
- Supabase
- PostgreSQL

---

# Estrutura

app/
components/
features/
hooks/
lib/
types/
services/
docs/

---

# Components

Apenas componentes reutilizáveis.

Exemplos:

Button

Input

Card

Modal

Sidebar

Header

Avatar

Charts

---

# Features

Toda regra de negócio.

dashboard

empreendimentos

imoveis

clientes

crm

proprietarios

agenda

financeiro

site

advisor

---

# App

Somente rotas.

Nenhuma regra de negócio.

---

# Hooks

Hooks globais.

---

# Services

Integrações.

---

# Types

Interfaces globais.

---

# Banco

Supabase

---

# Fluxo

Lead

↓

CRM

↓

Cliente

↓

Negócio

↓

Imóvel

↓

Contrato

↓

Financeiro

↓

Pós-venda

---

# Princípios

Nunca duplicar código.

Toda regra de negócio fica em Features.

Components nunca acessam Supabase.

Pages nunca fazem consultas diretamente.

Toda consulta passa pelos Services.

Todo Service retorna Types.

Todo formulário usa Components compartilhados.
