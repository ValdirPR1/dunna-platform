import Link from "next/link";

export default function EmpreendimentoPage() {
  return (
    <div className="bg-white">

      {/* Hero */}

      <section className="relative h-[520px] bg-slate-200">

        <div className="absolute inset-0 bg-black/40" />

        <div className="absolute bottom-14 left-1/2 w-full max-w-7xl -translate-x-1/2 px-6">

          <span className="rounded-full bg-[#C8A96A] px-4 py-2 text-sm font-semibold text-white">
            LANÇAMENTO
          </span>

          <h1 className="mt-6 text-6xl font-bold text-white">
            Makani Residence
          </h1>

          <p className="mt-3 text-xl text-white/90">
            Praia dos Carneiros • Pernambuco
          </p>

        </div>

      </section>

      {/* Conteúdo */}

      <section className="mx-auto max-w-7xl px-6 py-20">

        <div className="grid gap-16 lg:grid-cols-[2fr_1fr]">

          <div>

            <h2 className="text-4xl font-bold">
              Sobre o empreendimento
            </h2>

            <p className="mt-8 text-lg leading-9 text-slate-600">
              O Makani Residence foi pensado para quem busca
              qualidade de vida, rentabilidade e proximidade
              com uma das praias mais bonitas do Brasil.
            </p>

            <div className="mt-16 grid grid-cols-2 gap-8 md:grid-cols-4">

              <div>
                <h3 className="text-3xl font-bold">1 e 2</h3>
                <p className="text-slate-500">Quartos</p>
              </div>

              <div>
                <h3 className="text-3xl font-bold">35m²</h3>
                <p className="text-slate-500">até 72m²</p>
              </div>

              <div>
                <h3 className="text-3xl font-bold">
                  Piscina
                </h3>

                <p className="text-slate-500">
                  Rooftop
                </p>

              </div>

              <div>
                <h3 className="text-3xl font-bold">
                  150m
                </h3>

                <p className="text-slate-500">
                  do mar
                </p>

              </div>

            </div>

          </div>

          <aside className="rounded-3xl border border-slate-200 p-8 shadow-sm">

            <p className="text-slate-500">
              A partir de
            </p>

            <h2 className="mt-3 text-5xl font-bold">
              R$ 495 mil
            </h2>

            <button className="mt-10 w-full rounded-2xl bg-[#C8A96A] py-4 text-lg font-semibold text-white">
              Falar com especialista
            </button>

            <Link
              href="/site/imoveis"
              className="mt-4 block text-center font-semibold text-[#C8A96A]"
            >
              Ver unidades disponíveis
            </Link>

          </aside>

        </div>

      </section>

    </div>
  );
}