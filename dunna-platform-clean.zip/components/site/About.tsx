export default function About() {
  return (
    <section className="bg-white py-24">

      <div className="mx-auto grid max-w-7xl gap-16 px-6 lg:grid-cols-2">

        <div>

          <span className="font-semibold text-[#C8A96A]">
            SOBRE A DUNNA
          </span>

          <h2 className="mt-4 text-5xl font-bold text-slate-900">
            Especialistas em imóveis de praia.
          </h2>

          <p className="mt-8 text-lg leading-9 text-slate-600">
            Há mais de 10 anos conectamos pessoas aos melhores
            empreendimentos do litoral pernambucano.

            Atuamos em Porto de Galinhas,
            Muro Alto,
            Praia dos Carneiros,
            Tamandaré
            e São Miguel dos Milagres.
          </p>

          <div className="mt-12 grid grid-cols-2 gap-8">

            <div>

              <h3 className="text-4xl font-bold text-[#C8A96A]">
                +10
              </h3>

              <p className="mt-2 text-slate-500">
                anos de experiência
              </p>

            </div>

            <div>

              <h3 className="text-4xl font-bold text-[#C8A96A]">
                +500
              </h3>

              <p className="mt-2 text-slate-500">
                imóveis comercializados
              </p>

            </div>

          </div>

        </div>

        <div className="rounded-3xl bg-slate-200" />

      </div>

    </section>
  );
}