"use client";

import Link from "next/link";
import Image from "next/image";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6">

        <Link href="/site">

          <Image
            src="/logo/dunna-platform.png"
            alt="Dunna"
            width={170}
            height={45}
            priority
          />

        </Link>

        <nav className="hidden items-center gap-10 lg:flex">

          <Link href="/site">
            Home
          </Link>

          <Link href="/site/imoveis">
            Imóveis
          </Link>

          <Link href="/site/empreendimentos">
            Empreendimentos
          </Link>

          <Link href="/site/sobre">
            Sobre
          </Link>

          <Link href="/site/contato">
            Contato
          </Link>

        </nav>

        <a
          href="https://wa.me/5581999999999"
          className="rounded-xl bg-[#C8A96A] px-6 py-3 font-semibold text-white transition hover:opacity-90"
        >
          Falar com especialista
        </a>

      </div>
    </header>
  );
}