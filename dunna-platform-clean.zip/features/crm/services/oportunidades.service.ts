import { supabase } from "@/lib/supabase";

export async function listarOportunidades() {

  const { data, error } = await supabase

    .from("oportunidades")

    .select("*")

    .order("created_at", {
      ascending: false,
    });

  if (error) throw error;

  return data ?? [];

}