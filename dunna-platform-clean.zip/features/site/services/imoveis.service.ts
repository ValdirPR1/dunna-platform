import { supabase } from "@/lib/supabase";

export async function getFeaturedProperties() {
  const { data, error } = await supabase
    .from("imoveis")
    .select("*")
    .eq("publicado", true)
    .order("created_at", { ascending: false })
    .limit(6);

  if (error) {
    console.error(error);
    return [];
  }

  return data;
}

export async function getPropertyBySlug(slug: string) {
  const { data, error } = await supabase
    .from("imoveis")
    .select("*")
    .eq("slug", slug)
    .single();

  if (error) {
    return null;
  }

  return data;
}