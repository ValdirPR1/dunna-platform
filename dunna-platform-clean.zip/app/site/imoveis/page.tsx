import PropertyCard from "@/features/site/components/PropertyCard";

const propriedades = [
  {
    id: "1",
    titulo: "Makani Residence",
    cidade: "Praia dos Carneiros",
    preco: "R$ 495.000",
  },
  {
    id: "2",
    titulo: "Palm Beach",
    cidade: "Porto de Galinhas",
    preco: "R$ 690.000",
  },
  {
    id: "3",
    titulo: "Beach Class Wave",
    cidade: "Muro Alto",
    preco: "R$ 820.000",
  },
];

export default function ImoveisPage() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-16">

      <h1 className="text-5xl font-bold">
        Imóveis
      </h1>

      <p className="mt-4 text-lg text-slate-500">
        Encontre o imóvel ideal para morar, investir ou rentabilizar.
      </p>

      <div className="mt-12 grid gap-8 lg:grid-cols-3">

        {propriedades.map((item) => (

          <PropertyCard
            key={item.id}
            id={item.id}
            titulo={item.titulo}
            cidade={item.cidade}
            preco={item.preco}
          />

        ))}

      </div>

    </div>
  );
}