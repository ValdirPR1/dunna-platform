import Hero from "@/components/site/Hero";
import SearchBar from "@/components/site/SearchBar";
import Regions from "@/components/site/Regions";
import FeaturedDevelopments from "@/components/site/FeaturedDevelopments";
import FeaturedProperties from "@/components/site/FeaturedProperties";
import About from "@/components/site/About";
import CTA from "@/components/site/CTA";

export default function HomePage() {
  return (
    <>
      <Hero />

      <SearchBar />

      <Regions />

      <FeaturedDevelopments />

      <FeaturedProperties />

      <About />

      <CTA />
    </>
  );
}